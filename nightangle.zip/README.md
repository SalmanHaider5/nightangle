# NightAngle
UK based application for Nursing Homes and Medical Professionals

## Getting Started
* Create Database `nightangle`
* To run the application 
```
npm run start
```

