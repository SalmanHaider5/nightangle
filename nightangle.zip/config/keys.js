module.exports = {
    nodemailer: {
        host: 'nmcprofessionals.org.uk', // for gmail: smtp.gmail.com
        port: 465, // 587
        email: 'account@nmcprofessionals.org.uk',
        passowrd: 'nmcPro@9492',
        secure: true // for local: false
    },
    messagebird: {
        key: 'zjaxTCPiBJRkAWOCW3gs2jQVA'
    },
    stripe: {
        key: 'sk_test_1CKG3l4djbNIKfpHOD3Yrs3o00s2auBOs1'
    },
    config: {
        server: 'https://nmcprofessionals.org.uk/server/',
        app: 'https://nmcprofessionals.org.uk',
        secret: 'nmc_pro'
    }
}