module.exports = {
    HOST: 'localhost',
    USER: 'zeropdqq_nmc',
    PASSWORD: 'nmcPro@9492',
    DB: 'zeropdqq_nmc_pro',
    DIALECT: 'mysql'
}