// module.exports = {
//     HOST: 'us-cdbr-east-06.cleardb.net',
//     USER: 'b283d631f7f213',
//     PASSWORD: 'd84c1701',
//     DB: 'heroku_2898a17434132c6',
//     DIALECT: 'mysql'
// }

module.exports = {
    HOST: 'localhost',
    USER: 'zeropdqq_dev',
    PASSWORD: 'care@1234',
    DB: 'zeropdqq_nmc',
    DIALECT: 'mysql'
}

// module.exports = {
//     HOST: 'localhost',
//     USER: 'root',
//     PASSWORD: '',
//     DB: 'nightingale',
//     DIALECT: 'mysql'
// }